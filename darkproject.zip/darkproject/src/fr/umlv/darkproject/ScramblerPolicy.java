/*
 * Created on 27 d�c. 2004
 *
 */
package fr.umlv.darkproject;

/** D�finie une politique d'embrouillage.
 * Cette classe fournit pour un item un renommeur particulier.
 * @author remi
 *
 */
public interface ScramblerPolicy {
  /** Renvoie un renommeur pour une classe.
   * @param clazz la classe qui peut �tre renomm�.
   * @return renvoie un renommer pour la classe ou
   *  null si cette classe ne doit pas �tre renomm�e.
   */
  NameScrambler<ClassInfo> scrambleClass(ClassInfo clazz);
  
  /** Renvoie un renommeur pour un champs.
   * @param field le champs qui peut �tre renomm�.
   * @return renvoie un renommeur pour le champs ou
   *  null si ce champs ne peut �tre renomm�.
   */
  NameScrambler<FieldInfo> scrambleField(FieldInfo field);
  
  /** Renvoie un renommeur pour une m�thode.
   * @param method lea m�thode qui peut �tre renomm�e.
   * @return renvoie un renommeur pour la m�thode ou
   *  null si cette m�thode ne peut �tre renomm�e.
   */
  NameScrambler<MethodInfo> scrambleMethod(MethodInfo method);
}
