/*
 * Created on 31 d�c. 2004
 *
 */
package fr.umlv.darkproject;

import java.io.IOException;

/** Lecteur de JAR.
 * @author forax
 * @see fr.umlv.darkproject.ClassInfoManager
 */
public interface JarReader {
  /** lit le JAR et stocke l'ensemble des classes contenu dans
   *  le JAR et stocke ceux-ci dans le gestionnaire de classe.
   * @throws IOException s'il y a une erreur de lecture du JAR.
   */
  public void read() throws IOException;
  
  /** renvoie le nom de la classe indiqu� comme <code>Main-Class</code>
   *  dans le JAR.
   * @return renvoie le nom de la classe principale.
   * @throws IOException s'il y a une erreur de la lecture du JAR.
   */
  public String getMainClassName() throws IOException;
}