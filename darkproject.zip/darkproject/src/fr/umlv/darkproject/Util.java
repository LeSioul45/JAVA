/*
 * Created on 29 d�c. 2004
 *
 */
package fr.umlv.darkproject;

import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.util.EnumSet;
import java.util.Set;

import org.objectweb.asm.Type;

import static fr.umlv.darkproject.AccessModifier.*;

/**
 * @author remi
 *
 */
public class Util {
  private Util() {
    //must not be instantiated
  }
  
  /** Transforme un nom de fichier contenant une class (*.class) 
   *  sous forme d'un nom de classe en notation interne.
   * <code>fr/umlv/darkproject/Toto.class</code> vers <code>fr/umlv/darkproject/Toto</code>
   * @param filename
   */
  public static String extractInternalClassName(String filename) {
    return filename.substring(0,filename.length()-6);
  }
  
  /** renvoie un ensemble de modificateurs d'accessibilit� en fonction
   *  d'un entier representant le codage de ces modificateur dans le byte-code.
   * @param access entier repr�sentant les modificateurs d'accessibilit� 
   * @return un ensemble de modificateur de visibilit�.
   */
  public static Set<AccessModifier> getAccessModifierFromInt(int access) {
    EnumSet<AccessModifier> modifiers=EnumSet.noneOf(AccessModifier.class);
    if (Modifier.isPrivate(access))
      modifiers.add(PRIVATE);
    else
      if (Modifier.isProtected(access))
        modifiers.add(PROTECTED);
      else
        if (Modifier.isPrivate(access))
          modifiers.add(PUBLIC);
        else
          modifiers.add(DEFAULT);
    if (Modifier.isStatic(access))
      modifiers.add(STATIC);
    return modifiers;
  }
  
  /** renvoie une chaine de caract�re correspondant � un descripteur de champs renomm�
   *  � partir d'un descripteur de champs et du gestionnaire de classe qui maintient
   *  l'association entre l'ancien nom et le nouveau nom des classes.
   *  
   * @param manager le gestionnaire de classe
   * @param descriptor le descripteur de champs au format du byte-code.
   * @return une chaine de caract�re codant le type d'un champs dans le byte-code.
   */
  public static String rewriteFieldDescriptor(ClassInfoManager manager,String descriptor) {
    return rewriteDescriptor(manager,Type.getType(descriptor));
  }
  
  /** renvoie une chaine de caract�re correspondant � un descripteur de m�thode renomm�
   *  � partir d'un descripteur de m�thode et du gestionnaire de classe qui maintient
   *  l'association entre l'ancien nom et le nouveau nom des classes.
   *  
   * @param manager le gestionnaire de classe
   * @param methodDescriptor le descripteur de m�thode au format du byte-code.
   * @return une chaine de caract�re codant le type de retour et le type des param�tres
   *  d'une m�thode dans le byte-code.
   */
  public static String rewriteMethodDescriptor(ClassInfoManager manager,String methodDescriptor) {
    Type returnType=Type.getType(rewriteDescriptor(manager,Type.getReturnType(methodDescriptor)));
    Type[] types=Type.getArgumentTypes(methodDescriptor);
    for(int i=0;i<types.length;i++)
      types[i]=Type.getType(rewriteDescriptor(manager,types[i]));
    return Type.getMethodDescriptor(returnType,types);
  }
  
  private static String rewriteDescriptor(ClassInfoManager manager,Type type) { 
    switch(type.getSort()) {
      case Type.BOOLEAN:
      case Type.BYTE:
      case Type.CHAR:
      case Type.SHORT:
      case Type.INT:
      case Type.LONG:  
      case Type.FLOAT:
      case Type.DOUBLE:
      case Type.VOID:
        return type.getDescriptor();
        
      case Type.OBJECT:
        ClassInfo classInfo=manager.getClassInfo(type.getInternalName());
        if (classInfo==null)
          return type.getDescriptor();
        return 'L'+classInfo.getObfuscatedName()+';';
       
      case Type.ARRAY:
        return '['+rewriteDescriptor(manager,type.getElementType());
    }
    throw new AssertionError("unknown type "+type);
  }
  
  /** charge une classe � partir de son nom interne dans la machine virtuelle.
   * @param internalClassName nom de la classe avec la notation interne du byte-code.
   * @return une classe correspondant au nom pass� en param�tre.
   */
  public static Class<?> loadClass(String internalClassName) {
    try {
      return Class.forName(internalClassName.replace('/','.'));
    } catch (ClassNotFoundException e) {
      throw new AssertionError(e);
    }
  }
  
  /** renvoie le descriptor au format byte-code d'un champs
   *  obtenu par reflexion.
   * @param field champs d'une classe obtenu par reflexion.
   * @return renvoie le descripteur au format byte-code.
   */
  public static String getFieldDescriptor(Field field) {
    return Type.getDescriptor(field.getType());
  }
  
  /** renvoie le descriptor au format byte-code d'une m�thode
   *  obtenu par reflexion.
   * @param method m�thode d'une classe obtenue pa reflexion.
   * @return renvoie le descripteur au format byte-code.
   */
  public static String getMethodDescriptor(Method method) {
    return Type.getMethodDescriptor(method);
  }
  
  //it's a cut&paste from org.objectweb.asm.Type.getDescriptor(Method)
  //ASM: a very small and fast Java bytecode manipulation framework
  //Copyright (c) 2000,2002,2003 INRIA, France Telecom
  //All rights reserved.
  /** renvoie le descripteur au format byte-code d'un constructeur
   *  obtenu par reflexion.
   * @param constructor constructeur obtenu par reflexion.
   * @return renvoie le descripteur au format byte-code.
   */
  public static String getConstructorDescriptor(Constructor constructor) {
    Class[] parameters = constructor.getParameterTypes();
    StringBuilder buf = new StringBuilder();
    buf.append('(');
    for (int i = 0; i < parameters.length; ++i) {
      getDescriptor(buf, parameters[i]);
    }
    buf.append(")V");
    return buf.toString();
  }
  
  
  // it's a cut&paste from org.objectweb.asm.Type.getDescriptor(StringBuffer,Class)
  //ASM: a very small and fast Java bytecode manipulation framework
  //Copyright (c) 2000,2002,2003 INRIA, France Telecom
  //All rights reserved.
  private static void getDescriptor(final StringBuilder buf, final Class c) {
    Class d = c;
    while (true) {
      if (d.isPrimitive()) {
        char car;
        if (d == Integer.TYPE) {
          car = 'I';
        } else if (d == Void.TYPE) {
          car = 'V';
        } else if (d == Boolean.TYPE) {
          car = 'Z';
        } else if (d == Byte.TYPE) {
          car = 'B';
        } else if (d == Character.TYPE) {
          car = 'C';
        } else if (d == Short.TYPE) {
          car = 'S';
        } else if (d == Double.TYPE) {
          car = 'D';
        } else if (d == Float.TYPE) {
          car = 'F';
        } else /*if (d == Long.TYPE)*/ {
          car = 'J';
        }
        buf.append(car);
        return;
      } else if (d.isArray()) {
        buf.append('[');
        d = d.getComponentType();
      } else {
        buf.append('L');
        String name = d.getName();
        int len = name.length();
        for (int i = 0; i < len; ++i) {
          char car = name.charAt(i);
          buf.append(car == '.' ? '/' : car);
        }
        buf.append(';');
        return;
      }
    }
  }
}
