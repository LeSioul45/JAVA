/*
 * Created on 27 d�c. 2004
 *
 */
package fr.umlv.darkproject;

/** Class definissant un founisseur de nouveau nom � partir
 *  d'un item existant.
 *  La param�tre de type I correspond au type auquel le renommer est associ�,
 *  classe, m�thode ou champs.
 *  
 * @author remi
 */
public interface NameScrambler<I extends ItemInfo> {
  /** renvoie le nouveau nom de l'item.
   * @param item item � renommer.
   * @return le nouveau nom de l'item.
   */
  public String scramble(I item);
}
