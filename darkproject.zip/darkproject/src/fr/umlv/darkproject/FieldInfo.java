/*
 * Created on 27 d�c. 2004
 *
 */
package fr.umlv.darkproject;

/** Repr�sente un champs.
 * 
 * @author remi
 */
public interface FieldInfo extends MemberInfo {
  // no member here for the moment
}
