/*
 * Created on 31 d�c. 2004
 *
 */
package fr.umlv.darkproject;


/** Objet quyi permet d'embrouiller un ensemble de
 *  classe/m�thode/champs stock�s dans
 *  le {@link ClassInfoManager ClassInfoManager}
 * @author forax
 *
 */
public interface Obfuscator {
  
  /** Embrouille un ensemble de classe/m�thode/champs stock�s dans
   *  le {@link ClassInfoManager ClassInfoManager}, � partir duquel l'objet
   *  {@link Obfuscator Obfuscator} courant est cr��,
   *  en utilisant une politique de renommage.
   * @param policy politique de renommage.
   */
  public void obfuscate(ScramblerPolicy policy);
}