/*
 * Created on 28 d�c. 2004
 *
 */
package fr.umlv.darkproject;

/** Repr�sentes les modificateurs pouvant intervenir devant un
 *  champs une m�thode ou une classe.
 *  Par rapport � la sp�cification de Java tous ne sont pas pr�sent,
 *  uniquement ceux qui ont une importantce pour l'embrouillage
 *  de byte-code.
 *  
 * @author remi
 */
public enum AccessModifier {
  PRIVATE, DEFAULT, PROTECTED, PUBLIC, STATIC
}
