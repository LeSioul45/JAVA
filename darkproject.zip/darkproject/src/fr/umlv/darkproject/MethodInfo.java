/*
 * Created on 27 d�c. 2004
 *
 */
package fr.umlv.darkproject;

import java.util.List;

/** Repr�sente une m�thode.
 * @author remi
 */
public interface MethodInfo extends MemberInfo {
  /** Renvoie le ou les m�thodes de la super-classe (ou des anc�tres)
   *   ou une des super-interfaces (ou des anc�tres aussi)
   *   que la m�thode courante red�finit si elles existent.
   *  Exemple :
   *    si la m�thode courante est java/util/Date#toString alors
   *    la m�thode renvoy� est java/lang/Object#toString. 
   *  
   * @return une liste non modifiable de m�thode que la m�thode
   *  courante red�finie.
   */
  public List<MethodInfo> getOverridedMethod();
}
