/*
 * Created on 27 d�c. 2004
 *
 */
package fr.umlv.darkproject;

import java.util.Collection;

/** Permet de cr�er des objets r�pr�sentant des classes renommable ou non.
 * 
 * @author remi
 */
public interface ClassInfo extends ItemInfo {
  /** Indique si la classe est modifiable (renommable) ou pas
   * @return true si la classe est non-modifiable.
   */
  public boolean isReadOnly();
  
  /** Renvoie la super-classe de la classe courante.
   * @return peut �tre null dans le cas ou la classe n'a pas
   *  de super-classe (par exemple java/lang/Object) 
   */
  public ClassInfo getSuperclass();
  
  /** renvoie les interfaces de la classe courantes.
   * @return un tableau des interfaces implant�es ou un tableau vide
   *  si aucune classe n'est implant�.
   *  Le tableau renvoy� est un nouveau tableau � chaque appel.
   */
  public ClassInfo[] getInterfaces();
  
  /** renvoie le champs ayant pour ancien nom (avant renommage)
   *  <code>name</code> et pour ancien descripteur <code>descriptor</code>. 
   * @param name ancien nom du champs
   * @param descriptor ancien descripteur (au format du byte-code) du champs.
   * @return le champs ou null si celui-ci n'existe pas.
   */
  public FieldInfo getField(String name, String descriptor);
  
  /** renvoie l'ensemble des champs de la classe courante.
   * @return une collection non modifiable contenant l'ensemble
   *  des champs de la classe courante.
   */
  public Collection<FieldInfo> getFields();
  
  /** renvoie la m�thode ayant pour ancien nom (avant renommage)
   *  <code>name</code> et pour ancien descripteur <code>descriptor</code>. 
   * @param name ancien nom de la m�thode
   * @param descriptor ancien descripteur (au format du byte-code) de la m�thode.
   * @return la m�thode ou null si celle-ci n'existe pas.
   */
  public MethodInfo getMethod(String name, String descriptor);
  
  /** renvoie l'ensemble des m�thodes de la classe courante.
   * @return une collection non modifiable contenant l'ensemble
   *  des m�thodes de la classe courante.
   */
  public Collection<MethodInfo> getMethods();
}
