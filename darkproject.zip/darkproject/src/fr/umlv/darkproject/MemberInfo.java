/*
 * Created on 28 d�c. 2004
 *
 */
package fr.umlv.darkproject;

/** Interface de base pour les champs et les m�thodes.
 * @author remi
 *
 */
public interface MemberInfo extends ItemInfo {
  /** renvoie la classe contenant le membre courant.
   * @return la classe contenant le membre courant.
   */
  public ClassInfo getOwner();
  
  /** renvoie le descripteur originaml au format byte-code
   *  du membre courant.
   * @return le descripteur original.
   */
  public String getDescriptor();
  
  /** renvoie le descripteur apr�s renommage du membre courant.
   * @return le descripteur apr�s renommage du membre courant ou
   *  le descripteur original si celui-ci n'a pas �t� chang�.
   */
  public String getObfuscatedDescriptor();
  
  /** change le descripteur du membre courant. 
   * @param obfuscatedDescriptor descripteur apr�s renommage.
   */
  public void setObfuscatedDescriptor(String obfuscatedDescriptor);
}
