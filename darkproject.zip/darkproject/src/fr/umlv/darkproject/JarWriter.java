/*
 * Created on 31 d�c. 2004
 *
 */
package fr.umlv.darkproject;

import java.io.IOException;

/** Ecrivain permettant de cr�er un JAR � partir des classes
 *  modifiables contenu dans le gestionnaire de classe.
 * @author forax
 * @see fr.umlv.darkproject.ClassInfoManager
 */
public interface JarWriter {
  /** Ecrit l'ensemble des classes dans un JAR. 
   * @throws IOException s'il y a une erreur d'�criture du JAR.
   */
  public void write() throws IOException;
}