/*
 * Created on 28 d�c. 2004
 *
 */
package fr.umlv.darkproject;

import java.util.Set;

/** Interface de base pour repr�senter des classes/des m�thodes et des champs. 
 * 
 * @author remi
 */
public interface ItemInfo {
  
  /** renvoie l'�tat g�ler ou non d'un item
   * @return true si l'item est gel� 
   * @see #setFrozen(boolean)
   */
  public boolean isFrozen();
  
  /** g�le/d�g�le un item pour emp�cher le renommage de celui-ci.
   *  Exemple: les m�thodes red�finies (comme par exemple toString())
   *   doivent �tre gel�es.
   * @param frozen true pour g�ler un item.
   */
  public void setFrozen(boolean frozen);
  
  /** Renvoie les modificateurs d'accessibilit� d'un item.
   * @return ensemble de modificateurs d'accessibilit�.
   */
  public Set<AccessModifier> getAccess();
  
  /** Renvoie le nom original de l'item.
   * @return le nom de l'item
   */
  public String getName();
  
  /** Renvoie le nom renomm� (embrouill�) de l'item.
   *  Si le nom n'a pas �t� renomm�
   * @return le nom renomm� de l'item ou le nom original
   *  si l'item n'est pas renomm�.
   */
  public String getObfuscatedName();
  
  /** Change le nom de l'item. 
   * @param obfuscatedName nouveau nom de l'item.
   * @exception IllegalStateException dans le cas ou l'item
   *  est gel� {@link #setFrozen(boolean) setFrozen}.
   */
  public void setObfuscatedName(String obfuscatedName);
}
