/*
 * Created on 29 déc. 2004
 *
 */
package fr.umlv.darkproject.main;


import java.io.File;
import java.io.IOException;
import java.util.jar.JarFile;

import fr.umlv.darkproject.ClassInfo;
import fr.umlv.darkproject.ClassInfoManager;
import fr.umlv.darkproject.FieldInfo;
import fr.umlv.darkproject.JarReader;
import fr.umlv.darkproject.JarWriter;
import fr.umlv.darkproject.MethodInfo;
import fr.umlv.darkproject.ScramblerPolicy;
import fr.umlv.darkproject.impl.ApplicationScramblerPolicy;
import fr.umlv.darkproject.impl.ClassInfoManagerImpl;

/**
 * @author forax
 *
 */
public class Main {
  
  public static void main(String[] args) throws IOException {
    JarFile jar=new JarFile("example1.jar");
    
    ClassInfoManager manager=new ClassInfoManagerImpl();
    JarReader reader=manager.createJarReader(jar);
    reader.read();
    
    boolean preservePackageName=true;
    ScramblerPolicy policy=new ApplicationScramblerPolicy(reader.getMainClassName(),preservePackageName);
    manager.createObfuscator().obfuscate(policy);
    
    // debug
    for(ClassInfo classInfo:manager.getMutableClassInfos()) {
      System.out.println(classInfo);	
      for(FieldInfo field:classInfo.getFields())
        System.out.println(field);
      for(MethodInfo method:classInfo.getMethods())
        System.out.println(method);
    }
    
    JarWriter writer=manager.createJarWriter(jar,new File("example1-rewrite.jar"));
    writer.write();
  }
}
