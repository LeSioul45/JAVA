/*
 * Created on 28 d�c. 2004
 *
 */
package fr.umlv.darkproject;

import java.io.File;
import java.util.List;
import java.util.Set;
import java.util.jar.JarFile;

/** Gestionnaire des informations des classes que l'on peut
 *  embrouiller. Dans le but de permettre de savoir s'il y a
 *  redefinition entre des m�thodes, il est possible de stocker
 *  des classes qui ne sont pas modifiables comme java/lang/Object.
 *  
 * @author remi
 */
public interface ClassInfoManager {
  
  /** Cr�e un objet ClassInfo � partir d'une classe externe au contexte.
   *  Cette classe est enregistr�e et disponible en utilisant
   *  {@link #getClassInfo(String) getClassInfo()}.
   *  Une classe qui n'est pas dans le JAR.
   *  La classe renvoy�e contient l'ensemble de ses champs et m�thodes
   *  obtenus par reflexion {@link Class#getDeclaredFields() clazz.getDeclaredField()} et 
   *  {@link Class#getDeclaredMethod(java.lang.String, java.lang.Class[]) clazz.getDeclaredMethod()}.
   *  
   * @param clazz la classe dynamique.
   * @return l'objet ClassInfo correspondant � la classe.
   */
  public ClassInfo createReadOnlyClassInfo(Class<?> clazz);
  
  /** Cr�e un objet ClassInfo � partir d'une classe renommable
   *  Cette classe est enregistr�e et disponible en utilisant
   *  {@link #getClassInfo(String) getClassInfo()} et
   *  {@link #getMutableClassInfos() getMutableClassInfos()}.
   *  La classe cr��e ne poss�de ni champs ni m�thode.
   *  
   * @param access ensemble des modificateurs de visibilit� de la classe.
   * @param name nom de la classe au format interne du byte-code.
   * @param superclass objet correspondant � la super-classe.
   * @param interfaces tableau des interfaces de la classe, ce param�tre ne peut �tre null.
   * @return l'objet ClassInfo correspondant � la classe renommable cr��e.
   */
  public ClassInfo createClassInfo(Set<AccessModifier> access,String name, ClassInfo superclass, ClassInfo[] interfaces);
  
  /** Renvoie la liste de toutes les classes qui peuvent changer de nom.
   * @return la liste des classes.
   */
  public List<ClassInfo> getMutableClassInfos();
  
  /** Renvoie l'objet ClassInfo correspondant au nom de la classe.
   * @param name nom de la classe au format interne du byte-code
   * (nom s�par� par des '/' pas des '.').
   * @return l'objet ClassInfo ou null si la classe n'est pas trouv�e.
   */
  public ClassInfo getClassInfo(String name);
  
  /** Cr�e un objet repr�sentant un champs d'une classe modifiable (renommable).
   * @param owner classe dans laquelle on veut rajouter un champs.
   * @param access modificateurs du champs
   * @param name nom du champs
   * @param descriptor descripteur du champs au format du byte-code.
   * @return un objet FieldInfo repr�sentant le champs cr��.
   */
  public FieldInfo createFieldInfo(ClassInfo owner,Set<AccessModifier> access,String name,String descriptor);
 
  /** Cr�e un objet repr�sentant une m�thode modifiable (renommable). 
   * @param owner classe dans laquelle on veut rajouter une m�thode.
   * @param access modificateurs de la m�thode.
   * @param name nom de la m�thode.
   * @param descriptor descripteur de la m�thode au format du byte-code.
   * @return un objet MethodInfo repr�sentant la m�thode cr��e.
   */
  public MethodInfo createMethodInfo(ClassInfo owner,Set<AccessModifier> access,String name,String descriptor);
  
  /** Cr�e une impl�mentation d'un embrouilleur de classe/m�thode/champs.
   * @return retour l'embrouilleur cr��.
   * @see Obfuscator
   */
  public Obfuscator createObfuscator();
  
  /** Cr�e un lecteur de classe stock�e dans un Jar.
   *  Les classes charg�es seront stock�es dans le gestionnaire
   *  d'information des classes courants.
   * @param input JAR en entr�e.
   * @return renvoie un lecteur de JAR.
   */
  public JarReader createJarReader(JarFile input);
  
  /** Cr�e un ecrivain de JAR permettant d'�crire au format JAR
   *  le byte-code des classes modifiables stock�es dans le gestionnaire
   *  d'information des classes courants.
   * @param input JAR en entr�e.
   * @param output fichier correspondant au nom du JAR � �crire. 
   * @return renvoie un �crivain de JAR.
   */
  public JarWriter createJarWriter(JarFile input,File output);
}
