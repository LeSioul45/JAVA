package hello;

public interface Hello {
    public String hello (String msg);
}
