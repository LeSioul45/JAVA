import javax.naming.Context;
import javax.naming.InitialContext;
import java.util.*;

import calc.*;

public class CalcClient{
    public static void main(String[] args) throws Exception {
        Properties props = System.getProperties();
        props.put(Context.INITIAL_CONTEXT_FACTORY,
                  "org.jnp.interfaces.NamingContextFactory");
        props.put(Context.URL_PKG_PREFIXES,
                  "org.jboss.naming:org.jnp.interfaces");
        props.put(Context.PROVIDER_URL, "jnp://localhost:1099");

        Context ctx = new InitialContext(props);
        Calc calc = (Calc) ctx.lookup("CalcBean/remote");

        double somme = 0;
        somme = calc.add(5.643, 8.2921);
        System.out.println("Addition de 5.643 + 8.2921 = "+somme);
        somme = calc.mult(5.643, 8.2921);
        System.out.println("Multiplication de 5.643 x 8.2921 = "+somme);
    }
}
