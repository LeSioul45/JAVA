package article;

import javax.ejb.*;
import javax.persistence.*;
import java.util.*;

@Stateless 
public class ArticleAccessBean implements ArticleAccess {

  @PersistenceContext(unitName="Articles")
  EntityManager em;

  public int addArticle (String libelle, double prixUnitaire, String categorie){
    ArticleBean ab = new ArticleBean ();
    ab.setCategorie (categorie);
    ab.setLibelle (libelle);
    ab.setPrixUnitaire (prixUnitaire);
    em.persist(ab);
    em.flush(); 
    System.out.println ("AccessBean : Ajout de l'article "+ab.getIdArticle ());
    return ab.getIdArticle ();
  }
  
  public void delArticle (int idArticle){
      em.createQuery("DELETE FROM ArticleBean AS a WHERE a.idArticle="+idArticle);
  }
  
  public InfosArticle rechercherArticle (int idArticle){
    Query query = em.createQuery("SELECT a FROM ArticleBean AS a WHERE a.idArticle="+idArticle);

    List<ArticleBean> allArticles = query.getResultList();
        
    ArticleBean article = allArticles.get(0);
    return new InfosArticle (article.getIdArticle(), article.getLibelle(), article.getPrixUnitaire(), article.getCategorie());
  }
  
  public List rechercherTousLesArticles (){
        Query query = em.createQuery("SELECT a FROM ArticleBean AS a");
        List<ArticleBean> articlesbean = query.getResultList();
        Vector<InfosArticle> articles = new Vector(); 
        Iterator i = articlesbean.iterator();
        ArticleBean article;
        while (i.hasNext()) {
            article = (ArticleBean) i.next();
            InfosArticle infos = new InfosArticle (article.getIdArticle(), article.getLibelle(), article.getPrixUnitaire(), article.getCategorie());
            articles.add(infos);
        }
        return articles;            
   }
  
  public List rechercherLesArticlesParCategorie (String categorie){
        Query query = em.createQuery("SELECT a FROM ArticleBean AS a WHERE categorie='"+categorie+"'");
        List<ArticleBean> articlesbean = query.getResultList();            
        Vector<InfosArticle> articles = new Vector(); 
        Iterator i = articlesbean.iterator();
        ArticleBean article;
        while (i.hasNext()) {
            article = (ArticleBean) i.next();
            articles.add(new InfosArticle (article.getIdArticle(), article.getLibelle(), article.getPrixUnitaire(), article.getCategorie()));
        }
        return articles;            
   }
}
