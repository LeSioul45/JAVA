import javax.naming.*;
import javax.jms.*;
import java.util.*;

public class Client {

	public static void main (String[] args) throws Exception {
	
        Properties props = System.getProperties();
        props.put(Context.INITIAL_CONTEXT_FACTORY, "org.jnp.interfaces.NamingContextFactory");
        props.put(Context.URL_PKG_PREFIXES, "org.jboss.naming:org.jnp.interfaces");
        props.put(Context.PROVIDER_URL, "jnp://localhost:1099");

		// Initialisation JNDI
		Context ctx = new InitialContext(props);
		
		// 1: recherche d'une fabrique de connexion via le JNDI
		TopicConnectionFactory  factory = (TopicConnectionFactory) ctx.lookup("ConnectionFactory");
		
		// 2: Utilisation de la fabrique de connexions pour creer une connexion JMS
		TopicConnection connection = factory.createTopicConnection();
	
		// 3: Utilisation de la connexion pour creer une session
		TopicSession session = connection.createTopicSession(false, Session.AUTO_ACKNOWLEDGE);

		// 4: Recherche du sujet (topic) via JNDI
		javax.jms.Topic topic = (javax.jms.Topic) ctx.lookup("topic/MessageBean");
	
		// 5: Creation d'un producteur de message
		TopicPublisher publisher = session.createPublisher(topic);
	
		// 6: Creation d'un  message texte et publication
		TextMessage msg = session.createTextMessage();
		for (int i=0;i<10;i++){
			msg.setText("Envois message : " + i);
			publisher.publish(msg);
		}
 	}
}