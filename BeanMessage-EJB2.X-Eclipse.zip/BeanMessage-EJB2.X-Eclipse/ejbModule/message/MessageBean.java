package message;

import javax.ejb.*;
import javax.jms.*;

public class MessageBean implements MessageDrivenBean, MessageListener {
    
	private static final long serialVersionUID = 1L;
	protected MessageDrivenContext ctx;
    
    //association de cette instance du bean a un contexte particulier
    public void setMessageDrivenContext(MessageDrivenContext ctx) {
        this.ctx = ctx;
    }
    
    //Initialisation du bean
    public void ejbCreate() {
        System.out.println("ejbCreate()");
    }

    //Methode de reception des messages
    public void onMessage(Message msg) {

        TextMessage tm = (TextMessage) msg;

        try {
            String text = tm.getText();
            System.out.println("Message Recu : " + text);
        }catch(JMSException e) {
            e.printStackTrace();
        }
    }

    //Destruction du bean
    public void ejbRemove() {
        System.out.println("ejbRemove()");
    }

}
