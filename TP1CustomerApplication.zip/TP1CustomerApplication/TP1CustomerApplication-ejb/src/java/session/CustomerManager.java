/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package session;

import entities.Customer;
import entities.DiscountCode;
import java.util.List;
import javax.ejb.Stateless;
import javax.ejb.LocalBean;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

/**
 *
 * @author michel
 */
@Stateless
@LocalBean
public class CustomerManager {

    @PersistenceContext(unitName = "TP1CustomerApplication-ejbPU")
    private EntityManager em;

    public List<Customer> getAllCustomers(boolean forceRefresh) {
        Query query = em.createNamedQuery("Customer.findAll");
        // Cette liste provient du cache de niveau 2 et 1
        // Si les données changent en insert/delete, la liste est à jour
        // Mais pas forcément les updates
        List<Customer> liste = query.getResultList();
        
        // Force le refresh des valeurs
        if(forceRefresh) {
            for (Customer customer : liste) {
                // em.refresh force le rafraichissement des
                // attributs de l'objet en mémoire en fonction
                // des dernières valeurs pour cet objet, dans la base
                // (au plus près du dernier commit)
                em.refresh(customer);               
            }
        }
        
        return liste;
    }

    // Add business logic below. (Right-click in editor and choose
    // "Insert Code > Add Business Method")
    public Customer update(Customer customer) {
        return em.merge(customer);
    }

    public void persist(Object object) {
        em.persist(object);
    }

    public Customer getCustomerById(int id) {
        System.out.println("#### JE VAIS CHERCHER LE CLIENT DANS LA BASE ###");
        return em.find(Customer.class, id);
    }

  
}
