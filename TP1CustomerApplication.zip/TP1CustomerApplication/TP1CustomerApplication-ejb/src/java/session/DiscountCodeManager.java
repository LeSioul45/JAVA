/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package session;

import entities.DiscountCode;
import java.util.List;
import javax.ejb.Stateless;
import javax.ejb.LocalBean;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

/**
 *
 * @author michel
 */
@Stateless
@LocalBean
public class DiscountCodeManager {

    @PersistenceContext(unitName = "TP1CustomerApplication-ejbPU")
    private EntityManager em;

    // Add business logic below. (Right-click in editor and choose
    // "Insert Code > Add Business Method")
    public List<DiscountCode> getDiscountCodes() {
        Query query = em.createNamedQuery("DiscountCode.findAll");
        return query.getResultList();
    }
    
    public DiscountCode getDiscountCodeFromStringCode(String code) {
        System.out.println("JE CHERCHE LE DISCOUNT CODE " + code);
        Query query = em.createNamedQuery("DiscountCode.findByDiscountCode");
        query.setParameter("discountCode", new Character(code.charAt(0)));
        return (DiscountCode) query.getSingleResult();
    }

    public void persist(Object object) {
        em.persist(object);
    }
}
