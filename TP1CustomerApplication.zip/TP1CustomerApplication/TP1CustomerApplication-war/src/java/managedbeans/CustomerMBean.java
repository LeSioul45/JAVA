/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package managedbeans;

import entities.Customer;
import entities.DiscountCode;
import javax.ejb.EJB;
import javax.inject.Named;
import java.io.Serializable;
import java.util.List;
import javax.enterprise.context.SessionScoped;
import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;
import javax.faces.convert.Converter;
import javax.servlet.http.HttpSession;
import session.CustomerManager;
import session.DiscountCodeManager;

/**
 *
 * @author michel
 */
@Named(value = "customerMBean")
@SessionScoped
public class CustomerMBean implements Serializable {

    @EJB
    private DiscountCodeManager discountCodeManager;
    @EJB
    private CustomerManager customerManager;
    /* Client courant dans la session, utilisé pour afficher ses détails ou
     * pour faire une mise à jour du client modifié dans la base */
    private Customer customer;
    private int id;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        System.out.println("#### DANS SET ID !!! ###");
        this.id = id;
    }

    public void preRenderView() {
        // Hack pour éviter l'erreur Cannot create a session after the response 
        // has been committed des datatables PrimeFaces

        HttpSession session = (HttpSession) FacesContext.getCurrentInstance().getExternalContext().getSession(true);
        refreshListOfCustomerFromDatabase();
    }


    public Customer getCustomer() {
        return customer;
    }

    public void setCustomer(Customer customer) {
        this.customer = customer;
    }

    public CustomerMBean() {
        System.out.println("BEAN CONSTRUIT !");
    }
    /**
     * Renvoie la liste des clients pour affichage dans une DataTable
     *
     * @return
     */
    /*
     public Collection getCustomers() {
     System.out.println("DANS GET CUSTOMERS");
     return customerManager.getAllCustomers();
     }
     */
    private List<Customer> custList = null;

    public List<Customer> getCustomers() {

        System.out.println("DANS GET CUSTOMERS");
        if (custList == null) {
            refreshListOfCustomerFromDatabase();
        }
        return custList;
    }

    /**
     * Renvoie les détails du client courant (celui dans l'attribut customer de
     * cette classe), qu'on appelle une propriété (property)
     *
     * @return
     */
    public Customer getDetails() {
        return customer;
    }

    /**
     * Action handler - appelé lorsque l'utilisateur sélectionne une ligne dans
     * la DataTable pour voir les détails
     *
     * @param customer
     * @return
     */
    public String showDetails(Customer customer) {
        this.customer = customer;
        //currentDiscoutCode = customer.getDiscountCode().getDiscountCode().toString();
        return "CustomerDetails?faces-redirect=true";
    }

    /**
     * Action handler - met à jour la base de données en fonction du client
     * passé en paramètres
     *
     * @return
     */
    public String update() {
        //DiscountCode code = discountCodeManager.getDiscountCodeFromStringCode(currentDiscoutCode);
        //customer.setDiscountCode(code);
        customer = customerManager.update(customer);
        return "CustomerList?faces-redirect=true";
    }

    /**
     * Action handler - renvoie vers la page qui affiche la liste des clients
     *
     * @return
     */
    public String list() {
        System.out.println("###LIST###");
        return "CustomerList?faces-redirect=true";
    }

    // Pour remplir la liste des discount codes
    public List<DiscountCode> getAllDiscountCodes() {
        return discountCodeManager.getDiscountCodes();
    }

    public Converter getDiscountCodeConverter() {
        return discountCodeConverter;
    }
    
    private Converter discountCodeConverter = new Converter() {
    @Override
    public Object getAsObject(FacesContext context, UIComponent component, String value) {
        System.out.println("Dans GET AS Object : " + value);
      char code = value.charAt(0);
      DiscountCode dc = discountCodeManager.getDiscountCodeFromStringCode(""+code);
      return dc;
    }

    @Override
    public String getAsString(FacesContext context, UIComponent component, Object value) {
        
      DiscountCode dc = (DiscountCode) value;
      return dc.getDiscountCode() + " : " + dc.getRate() + "%";
      
    }
  };
    

    public void refreshListOfCustomerFromDatabase() {
        // true force le refresh depuis la base
        custList = customerManager.getAllCustomers(true);

    }

    public void lireClientParId() {
        customer = customerManager.getCustomerById(id);
    }
}