package article;

import javax.persistence.*;
import java.io.*;

@Entity
public class ArticleBean implements Serializable {

	private static final long serialVersionUID = 1L;
	private int idArticle;
	private String categorie;
	private String libelle;
	private double prixUnitaire;

	public ArticleBean() { }

	public ArticleBean(String categorie, String libelle, double prixUnitaire) { 
		this.categorie = categorie;
		this.libelle = libelle;
		this.prixUnitaire = prixUnitaire;
	}

	public void setArticleBean(String categorie, String libelle, double prixUnitaire) { 
		this.categorie = categorie;
		this.libelle = libelle;
		this.prixUnitaire = prixUnitaire;
	}

	// accesseurs(1)
	public String getCategorie(){
		return categorie;
	}

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY) 
	public int getIdArticle(){
		return idArticle;
	}

	public String getLibelle(){
		return libelle;
	}

	public double getPrixUnitaire(){
		return prixUnitaire;
	}

	public void setCategorie(String categorie){
		this.categorie = categorie;
	}

	public void setIdArticle(int idArticle){
		this.idArticle = idArticle;
	}

	public void setLibelle(String libelle){
		this.libelle = libelle;
	}

	public void setPrixUnitaire(double prixUnitaire){
		this.prixUnitaire = prixUnitaire;
	}

}
