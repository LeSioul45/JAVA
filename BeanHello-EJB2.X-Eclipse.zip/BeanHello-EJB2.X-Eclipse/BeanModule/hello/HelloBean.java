package hello;

import javax.ejb.*;

public class HelloBean implements SessionBean{
    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	/*public String hello(){
    	return "Hello World / Bonjour le monde";
    }*/
	
    public String hello(String msg){
    	return "Bonjour "+msg;
    }
	
    public void ejbCreate(){}
    public void ejbRemove(){}
    public void ejbActivate(){}
    public void ejbPassivate(){}
    public void setSessionContext(SessionContext ctx){}
}	
