package hello;

import javax.ejb.*;

public interface HelloLocalHome extends EJBLocalHome{
    HelloLocal create() throws CreateException;
}	
