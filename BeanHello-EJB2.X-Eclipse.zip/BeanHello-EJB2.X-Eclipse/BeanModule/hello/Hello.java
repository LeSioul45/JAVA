package hello;

import java.rmi.*;
import javax.ejb.*;

public interface Hello extends EJBObject{
    public String hello(String msg) throws RemoteException;
}
