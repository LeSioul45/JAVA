package hello;

import javax.ejb.*;

public interface HelloLocal extends EJBLocalObject{
    public String hello(String msg);
}
