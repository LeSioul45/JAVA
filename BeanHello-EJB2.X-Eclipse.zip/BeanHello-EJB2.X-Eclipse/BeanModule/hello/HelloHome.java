package hello;

import java.rmi.*;
import javax.ejb.*;

public interface HelloHome extends EJBHome{	
    Hello create() throws RemoteException, CreateException;
}	
