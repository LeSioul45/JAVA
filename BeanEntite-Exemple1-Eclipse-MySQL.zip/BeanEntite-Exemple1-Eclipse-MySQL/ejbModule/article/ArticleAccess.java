package article;

import javax.ejb.Remote;
import java.util.*;

@Remote public interface ArticleAccess {

  public int addArticle (String libelle, double prixUnitaire, String categorie);
  public void delArticle (int idArticle);
  public InfosArticle rechercherArticle (int idArticle);
  public List rechercherLesArticlesParCategorie (String categorie);
  public List rechercherTousLesArticles ();
}
