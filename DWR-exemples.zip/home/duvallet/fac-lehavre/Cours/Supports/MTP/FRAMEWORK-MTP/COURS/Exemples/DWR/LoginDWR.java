import java.util.ArrayList;
import java.util.List;
 
public class LoginDWR {
    /**
    * M�thode asynchrone permettant de valider l'authentification de l'utilisateur.
    * @param loginForm provenant de l'objet JavaScript automatiquement mapp� dans l'objet Java
    * @param request request de l'utilisateur, sert � utiliser la session notamment
    * @return une liste d'erreurs provenant de la validation
    */
    public List validateLogin(LoginForm loginForm, HttpServletRequest request) {
        List errorList = new ArrayList();
 
        /** validation de surface c�t� serveur */
        /** ********************************** */
        // validation du login
        if (loginForm.getLogin() == null) {
            errorList.add('Your login is required');
        } else {
            if (loginForm.getLogin().length() < 4) {
                errorList.add('Your login must be at least 4 characters');
            } else if (loginForm.getLogin().length() > 10) {
                errorList.add('Your login can not exceed 10 characters');
            }
        }
 
        // validation du password
        if (loginForm.getPassword() == null) {
            errorList.add('Your password is required');
        } else {
            if (loginForm.getPassword().length() < 6) {
                errorList.add('Your password must be at least 6 characters');
            } else if (loginForm.getPassword().length() > 20) {
                errorList.add('Your password can not exceed 20 characters');
            }
        }
 
        /** validation en profondeur */
        /** *********************** */
        if (errorList.isEmpty()) {
            // utilisation de vos classes m�tiers pour valider
            LoginService loginService = new LoginService();
            // regarde si l'utilisateur est connu (dans une base de donn�es ou un fichier xml, etc.)
            try {
                boolean loginKnown = loginService.isLoginKnown(loginForm);
                if (!loginKnown) {
                    errorList.add('Login or password is incorrect');
                }
            } catch (ServiceException e) {
                errorList.add('An technical error occured ' + e.getMessage());
            }
        }
        return errorList;
    }
}
