import javax.naming.*;
import java.util.*;
import utilisateur.*;

public class UtilisateurClient {

  public void creerUtilisateur(String nom, String prenom) {
        UtilisateurAccess ah;
        Properties props = System.getProperties();
        props.put(Context.INITIAL_CONTEXT_FACTORY, "org.jnp.interfaces.NamingContextFactory");
        props.put(Context.URL_PKG_PREFIXES, "org.jboss.naming:org.jnp.interfaces");
        props.put(Context.PROVIDER_URL, "jnp://localhost:1099");

        try {
            Context ctx = new InitialContext(props);
            ah = (UtilisateurAccess) ctx.lookup("UtilisateurAccessBean/remote");
            System.out.println ("Ajout d'un utilisateur !");
            int id = ah.addUtilisateur(nom, prenom);
            System.out.println ("Affichage de l'utilisateur "+id);
            afficherUtilisateur(id);
        } catch (Throwable th) {
            System.out.println("Erreur dans creerUtilisateur : " + th);
        }
   }

  public void creerUtilisateur(String nom, String prenom, int numRue, String nomRue, String codePostal, String ville, String pays) {
        UtilisateurAccess ah;
        Properties props = System.getProperties();
        props.put(Context.INITIAL_CONTEXT_FACTORY, "org.jnp.interfaces.NamingContextFactory");
        props.put(Context.URL_PKG_PREFIXES, "org.jboss.naming:org.jnp.interfaces");
        props.put(Context.PROVIDER_URL, "jnp://localhost:1099");

        try {
            Context ctx = new InitialContext(props);
            ah = (UtilisateurAccess) ctx.lookup("UtilisateurAccessBean/remote");
            System.out.println ("Ajout d'un utilisateur !");
            int id = ah.addUtilisateur(nom, prenom, numRue, nomRue, codePostal, ville, pays);
            System.out.println ("Affichage de l'utilisateur "+id);
            afficherUtilisateur(id);
        } catch (Throwable th) {
            System.out.println("Erreur dans creerUtilisateur : " + th);
        }
   }

  public void supprimerTousLesUtilisateurs() {
        UtilisateurAccess ah;
        Properties props = System.getProperties();
        props.put(Context.INITIAL_CONTEXT_FACTORY, "org.jnp.interfaces.NamingContextFactory");
        props.put(Context.URL_PKG_PREFIXES, "org.jboss.naming:org.jnp.interfaces");
        props.put(Context.PROVIDER_URL, "jnp://localhost:1099");

        try {
            Context ctx = new InitialContext(props);
            ah = (UtilisateurAccess) ctx.lookup("UtilisateurAccessBean/remote");
            System.out.println ("Suppression de tous les utilisateurs");
            ah.delTousLesUtilisateurs();
        } catch (Throwable th) {
            System.out.println("Erreur dans supprimerTousLesUtilisateurs : " + th);
        }
   }

  public void supprimerUtilisateur(int idUtil) {
        UtilisateurAccess ah;
        Properties props = System.getProperties();
        props.put(Context.INITIAL_CONTEXT_FACTORY, "org.jnp.interfaces.NamingContextFactory");
        props.put(Context.URL_PKG_PREFIXES, "org.jboss.naming:org.jnp.interfaces");
        props.put(Context.PROVIDER_URL, "jnp://localhost:1099");

        try {
            Context ctx = new InitialContext(props);
            ah = (UtilisateurAccess) ctx.lookup("UtilisateurAccessBean/remote");
            System.out.println ("Suppression d'un utilisateur");
            ah.delUtilisateur(idUtil);
        } catch (Throwable th) {
            System.out.println("Erreur dans supprimerUtilisateur : " + th);
        }
   }

  public void afficherUtilisateur(int idUtil) {
        UtilisateurAccess ah;
        Properties props = System.getProperties();
        props.put(Context.INITIAL_CONTEXT_FACTORY, "org.jnp.interfaces.NamingContextFactory");
        props.put(Context.URL_PKG_PREFIXES, "org.jboss.naming:org.jnp.interfaces");
        props.put(Context.PROVIDER_URL, "jnp://localhost:1099");

        try {
            Context ctx = new InitialContext(props);
            ah = (UtilisateurAccess) ctx.lookup("UtilisateurAccessBean/remote");
            InfosUtilisateur infos;
            infos = ah.rechercherUtilisateur(idUtil);
            System.out.println ("=====> Affichage des informations de l'utilisateur : "+idUtil);
            System.out.println ("Nom de l'utilisateur    : "+infos.nomUtilisateur);
            System.out.println ("Prenom de l'utilisateur : "+infos.prenomUtilisateur);
            if (infos.numeroRueUtilisateur!=0) 
                System.out.println ("Adresse: numero de rue  : "+infos.numeroRueUtilisateur);
            else
                System.out.println ("Adresse: numero de rue  : ");
            System.out.println ("Adresse: nom de rue     : "+infos.nomRueUtilisateur);
            System.out.println ("Adresse: code postal    : "+infos.codePostalUtilisateur);
            System.out.println ("Adresse: ville          : "+infos.villeUtilisateur);
            System.out.println ("Adresse: pays           : "+infos.paysUtilisateur);
        } catch (Throwable th) {
            System.out.println("Erreur dans afficherUtilisateur : " + th);
        }
   }


    public static void main(java.lang.String[] args) {

        UtilisateurClient a = new UtilisateurClient ();

        a.creerUtilisateur("Duvallet", "Claude", 208, "rue de Verdun", "76600", "Le Havre", "France");
        a.creerUtilisateur("Sadeg", "Bruno");
        a.creerUtilisateur("Amanton", "Laurent");
        a.creerUtilisateur("Fournier", "Dominique");
        a.supprimerUtilisateur(1);

        // Recherche de l'utilisateur 3
        System.out.println ("========= Affichage de l'utilisateur 3");
        a.afficherUtilisateur(2);
        //System.out.println ("========= Affichage de tous les utilisateurs");
        //a.afficherTousLesUtilisateurs();
   }
}
