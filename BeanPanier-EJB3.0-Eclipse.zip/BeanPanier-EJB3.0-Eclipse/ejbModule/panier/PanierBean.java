package panier;

import javax.ejb.Stateful;
import javax.annotation.PostConstruct;
import javax.ejb.Remove;
import java.util.*;

@Stateful
public class PanierBean implements Panier{
    Vector<Integer> articles;
    String nomClient;

    @PostConstruct 
    public void initialise() {
        articles = new Vector<Integer>();
        nomClient = "";
    }

    public void ajouterArticle(int idArticle) {
        System.out.println ("Ajout d'un nouvel article");
        articles.add(new Integer(idArticle));
    }

    public void supprimerArticle(int idArticle){
        System.out.println ("Suppression d'un article");
        articles.remove(new Integer(idArticle));
    }

    public Vector<Integer> listerArticles(){
        return articles;
    }

    public void setNom(String nomClient) {
        this.nomClient = nomClient;
    }

    public String getNom() {
        return nomClient;
    }
    
    @Remove
    public void remove() {
        articles = null;
    }
}
