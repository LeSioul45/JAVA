package panier;

import javax.ejb.Remote;
import java.util.*;

@Remote public interface Panier{
    public void ajouterArticle(int idArticle);
    public void supprimerArticle(int idArticle);
    public Vector<Integer> listerArticles();
    public void setNom(String nomClient);
    public String getNom();
    public void remove();
}
