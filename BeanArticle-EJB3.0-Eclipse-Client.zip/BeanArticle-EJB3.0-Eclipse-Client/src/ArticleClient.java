import java.util.Iterator;
import java.util.List;
import java.util.Properties;

import javax.naming.*;
import article.*;

public class ArticleClient {

	public void creerArticle(   String libelle, 
			double montantUnitaire, 
			String categorie) {
		ArticleAccess ah;
		Properties props = System.getProperties();
		props.put(Context.INITIAL_CONTEXT_FACTORY, "org.jnp.interfaces.NamingContextFactory");
		props.put(Context.URL_PKG_PREFIXES, "org.jboss.naming:org.jnp.interfaces");
		props.put(Context.PROVIDER_URL, "jnp://localhost:1099");

		try {
			Context ctx = new InitialContext(props);
			ah = (ArticleAccess) ctx.lookup("ArticleAccessBean/remote");
			int id = ah.addArticle(libelle, montantUnitaire, categorie);
			afficherArticle(id);
		} catch (Throwable th) {
			System.out.println("Erreur dans creerArticle : " + th);
		}
	}

	public void afficherArticle(int numeroArticle) {
		ArticleAccess ah;
		Properties props = new Properties();
		props.put("java.naming.factory.initial", "org.jnp.interfaces.NamingContextFactory");
		props.put("java.naming.factory.url.pkgs", "org.jboss.naming:org.jnp.interfaces");
		props.put("java.naming.provider.url", "localhost:1099");
		try {
			Context ic = new InitialContext(props);
			ah = (ArticleAccess) ic.lookup("ArticleAccessBean/remote");
			InfosArticle infos = ah.rechercherArticle(numeroArticle);
			System.out.println("voici les infos sur l'article : " + infos.idArticle);
			System.out.println("   id : " + infos.idArticle);
			System.out.println("   libelle : " + infos.libelle);
			System.out.println("   prix unitaire : " + infos.prixUnitaire);
			System.out.println("   categorie : " + infos.categorie);
		} catch (Throwable th) {
			System.out.println("GereCommande.creerArticle : " + th);
		}
	}

	public void afficherArticlesParCategorie(String categorie) {

		ArticleAccess ah;
		Properties props = new Properties();
		props.put("java.naming.factory.initial", "org.jnp.interfaces.NamingContextFactory");
		props.put("java.naming.factory.url.pkgs", "org.jboss.naming:org.jnp.interfaces");
		props.put("java.naming.provider.url", "localhost:1099");
		try {
			Context ic = new InitialContext(props);
			ah  = (ArticleAccess) ic.lookup("ArticleAccessBean/remote");
			List<InfosArticle> articles = ah.rechercherLesArticlesParCategorie(categorie);
			Iterator<InfosArticle> i = articles.iterator();
			InfosArticle article;
			while (i.hasNext()) {
				article = (InfosArticle) i.next();
				afficherArticle(article.idArticle);
			}
		} catch (Throwable th) {
			System.out.println("Erreur dans rechercherArticlesParCategorie : " + th);
		}
	}

	public void afficherTousLesArticles() {

		ArticleAccess ah;
		Properties props = new Properties();
		props.put("java.naming.factory.initial", "org.jnp.interfaces.NamingContextFactory");
		props.put("java.naming.factory.url.pkgs", "org.jboss.naming:org.jnp.interfaces");
		props.put("java.naming.provider.url", "localhost:1099");
		try {
			Context ic = new InitialContext(props);
			ah  = (ArticleAccess) ic.lookup("ArticleAccessBean/remote");
			List<InfosArticle> articles = ah.rechercherTousLesArticles();
			Iterator<InfosArticle> i = articles.iterator();
			InfosArticle article;
			while (i.hasNext()) {
				article = (InfosArticle) i.next();
				afficherArticle(article.idArticle);
			}
		} catch (Throwable th) {
			System.out.println("Erreur dans rechercherArticlesParCategorie : " + th);
		}
	}

	public static void main(java.lang.String[] args) {

		ArticleClient a = new ArticleClient ();

		System.out.println ("============== Creation des articles");
		a.creerArticle("Les miserables", 21, "LIVRE");
		a.creerArticle("Celine Dion au stade de France", 120, "CD");
		a.creerArticle("Je l'aime a mourir", 28, "LIVRE");
		a.creerArticle("La mer", 38, "LIVRE");

		// Recherche de l'article 3
		System.out.println ("============== Recherche de l'article 3");
		a.afficherArticle(3);
		System.out.println ("============== Recherche des articles de type CD");
		// Recherche de la categorie
		a.afficherArticlesParCategorie("CD");
	}
}
