import java.util.*;
import javax.naming.*;
import javax.naming.directory.*;

@SuppressWarnings("unchecked")
public class TestLDAPMTP {

	public static void main(String[] args) {
		Hashtable env = new Hashtable();
		env.put(Context.INITIAL_CONTEXT_FACTORY, "com.sun.jndi.ldap.LdapCtxFactory");
		env.put(Context.PROVIDER_URL, "ldap://localhost:389");
		env.put(Context.SECURITY_AUTHENTICATION, "simple");
		env.put(Context.SECURITY_PRINCIPAL, "cn=admin,dc=example,dc=com");
		env.put(Context.SECURITY_CREDENTIALS, "admin");

		DirContext dirContext;

		try {
			dirContext = new InitialDirContext(env);
			System.out.println ("Connexion a LDAP reussie");
			// Manipulation des attributs
			Attributes attributs = dirContext.getAttributes("cn=admin,dc=example,dc=com");
			Attribute attribut = (Attribute) attributs.get("description") ;
			System.out.println("Description : " + attribut.get());

			NamingEnumeration<NameClassPair> e = dirContext.list("cn=admin");
			while (e.hasMore()) {
				System.out.println("name: " + e.next().getName());
			}      

			/*      Attributes attributes = new BasicAttributes(true);
			      attribut = new BasicAttribute("telephoneNumber");
			      attribut.add("99.99.99.99.99");
			      attributes.put(attribut);*/

			attribut = (Attribute) attributs.get("telephoneNumber") ;
			System.out.println("Numero de telephone : " + attribut.get());

			dirContext.close();
		} catch (NamingException e) {
			System.err.println("Erreur lors de l'acces au serveur LDAP" + e);
			e.printStackTrace();
		}
	}
}
