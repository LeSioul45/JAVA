import java.util.*;
import javax.naming.*;
import javax.naming.directory.*;

@SuppressWarnings("unchecked")
public class TestLDAPExample {

	public static void main(String[] args) {
		Hashtable env = new Hashtable();
		env.put(Context.INITIAL_CONTEXT_FACTORY, "com.sun.jndi.ldap.LdapCtxFactory");
		env.put(Context.PROVIDER_URL, "ldap://localhost:389");
		env.put(Context.SECURITY_AUTHENTICATION, "simple");
		env.put(Context.SECURITY_PRINCIPAL, "cn=admin,dc=example,dc=com");
		env.put(Context.SECURITY_CREDENTIALS, "admin");

		DirContext dirContext;

		try {
			dirContext = new InitialDirContext(env);
			System.out.println ("Connexion au serveur LDAP reussie");
			// Manipulation des attributs
			Attributes attributs = dirContext.getAttributes("cn=admin,dc=example,dc=com");
			Attribute attribut = (Attribute) attributs.get("description") ;
			System.out.println("Description : " + attribut.get());

			NamingEnumeration<NameClassPair> e = dirContext.list("cn=admin,dc=example,dc=com");
			while (e.hasMore()) {
				System.out.println("name: " + e.next().getName());
			}      

			// R�cup�ration de l'attribut sn (Nom de famille)
			Attributes attributes = dirContext.getAttributes("cn=Saida Ameziane, ou=mtp, dc=example,dc=com");
			attribut = (Attribute) attributes.get("sn") ;
			System.out.println("Le nom de famille est : " + attribut.get());

			// Modification de l'organisation
			attribut = new BasicAttribute("o");
			attribut.add("Ministere des travaux publics");
			attributes.put(attribut);
			dirContext.modifyAttributes("cn=Saida Ameziane, ou=mtp, dc=example,dc=com", DirContext.REPLACE_ATTRIBUTE,attributes); 			

			// Ajout d'un num�ro de t�l�phone
			attributes = dirContext.getAttributes("cn=Nabila Bouafia, ou=mtp, dc=example,dc=com");
			attribut = new BasicAttribute("telephoneNumber");
			attribut.add("99.88.99.99.99");
			attributes.put(attribut);
			dirContext.modifyAttributes("cn=Nabila Bouafia, ou=mtp, dc=example,dc=com", DirContext.REPLACE_ATTRIBUTE,attributes);
			System.out.println("Ajout du numéro de téléphone pour Nabila");
			dirContext.close();
		} catch (NamingException e) {
			System.err.println("Erreur lors de l'acces au serveur LDAP" + e);
			e.printStackTrace();
		}
	}
}
