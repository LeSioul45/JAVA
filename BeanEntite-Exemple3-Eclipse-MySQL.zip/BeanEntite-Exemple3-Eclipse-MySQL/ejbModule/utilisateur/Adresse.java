package utilisateur;

import javax.persistence.*;
import java.io.*;

@Entity
@Table(name="Adresses")
public class Adresse implements Serializable {
  private int idAdresse;
  private int numeroRue;
  private String nomRue;
  private String codePostal;
  private String ville;
  private String pays;
  private Utilisateur utilisateur;

  public Adresse(){}

  @Id
  @GeneratedValue (strategy = GenerationType.IDENTITY)
  public int getIdAdresse (){
    return idAdresse;
  }

//  @OneToOne(mappedBy = "idAdresse")
  public void setIdAdresse (int idAdresse){
    this.idAdresse = idAdresse;
  }

  public int getNumeroRue (){
    return numeroRue;
  }

  public void setNumeroRue (int numeroRue){
    this.numeroRue = numeroRue;
  }

  public String getNomRue (){
    return nomRue;
  }

  public void setNomRue (String nomRue){
    this.nomRue = nomRue;
  }

  public String getCodePostal (){
    return codePostal;
  }

  public void setCodePostal (String codePostal){
    this.codePostal = codePostal;
  }

  public String getVille (){
    return ville;
  }

  public void setVille (String ville){
    this.ville = ville;
  }

  public String getPays (){
    return pays;
  }

  public void setPays (String pays){
    this.pays = pays;
  }

  public Utilisateur getUtilisateur (){
    return utilisateur;
  }

  public void setUtilisateur (Utilisateur user){
    utilisateur=user;
  }

}