package utilisateur;

import javax.ejb.*;
import javax.persistence.*;
import java.util.*;

@Stateless public class UtilisateurAccessBean implements UtilisateurAccess {

  @PersistenceContext(unitName="Utilisateurs2")
  EntityManager em;

  public int addUtilisateur (String nom, String prenom){
    Utilisateur util = new Utilisateur ();
    util.setNom(nom);
    util.setPrenom(prenom);
    em.persist(util);
    em.flush();
    System.out.println ("Ajout d'un nouvel utilisateur : "+nom+" "+prenom);
    return util.getIdUtilisateur ();
  }

  public int addUtilisateur (String nom, String prenom, int numRue, String nomRue, String codePostal, String ville, String pays){
    //System.out.println ("1.Ajout d'un nouvel utilisateur : "+nom+" "+prenom+" "+numRue+" "+nomRue+" "+codePostal+" "+ville+" "+pays);
    Adresse adresse = new Adresse ();
    adresse.setNumeroRue(numRue);
    adresse.setNomRue(nomRue);
    adresse.setCodePostal(codePostal);
    adresse.setVille(ville);
    adresse.setPays(pays);
    em.persist(adresse);
    em.flush();
    //System.out.println ("2.Ajout d'un nouvel utilisateur : "+nom+" "+prenom+" "+numRue+" "+nomRue+" "+codePostal+" "+ville+" "+pays);
    Utilisateur util = new Utilisateur ();
    util.setNom(nom);
    util.setPrenom(prenom);
    util.setAdresse(adresse);
    em.persist(util);
    em.flush();
    //System.out.println ("3.Ajout d'un nouvel utilisateur : "+nom+" "+prenom+" "+numRue+" "+nomRue+" "+codePostal+" "+ville+" "+pays);
    return util.getIdUtilisateur ();
  }

  public void setAdresse (int idUtil, int numRue, String nomRue, String codePostal, String ville, String pays){
    Adresse adresse = new Adresse ();
    adresse.setNumeroRue(numRue);
    adresse.setNomRue(nomRue);
    adresse.setCodePostal(codePostal);
    adresse.setVille(ville);
    adresse.setPays(pays);
    em.persist(adresse);
    em.flush();
    Utilisateur util = getUtilisateur(idUtil);
    util.setAdresse(adresse);
    em.persist(util);
    em.flush();
  }


  private Utilisateur getUtilisateur (int idUtil){
    //System.out.println ("Recherche de l'utilisateur");
    Query query = em.createQuery("SELECT user FROM Utilisateur AS user WHERE user.idUtilisateur="+idUtil);

    //System.out.println ("Requete effectuee !");
    List<Utilisateur> allUsers = query.getResultList();
    Utilisateur util = allUsers.get(0);
    //System.out.println("Recherche de l'utilisateur : "+util.getPrenom()+" "+util.getNom());
    return util;
  }
//   private Utilisateur getUtilisateur (int idUtil){
//     return em.find(Utilisateur.class,idUtil);
//   }

  private List<Utilisateur> getTousLesUtilisateurs (){
    System.out.println ("Recherche de tous les utilisateurs");
    Query query = em.createQuery("SELECT user FROM Utilisateur AS user");

    List<Utilisateur> allUsers = (List<Utilisateur>)query.getResultList();
    System.out.println("Il y a "+allUsers.size()+" utilisateurs");
    return allUsers;
  }

  public void delUtilisateur (int idUtil){
	// System.out.println("TEST");
    Utilisateur util = getUtilisateur(idUtil);
    System.out.println("Suppression de l'utilisateur : "+util.getPrenom()+" "+util.getNom());
    Adresse adr = util.getAdresse();
    
    /*Query query = em.createQuery("DELETE FROM Utilisateur AS user WHERE user.idUtilisateur="+idUtil);
    System.out.println("Query="+query.toString());
    System.out.println(query.executeUpdate()+" utilisateur supprime");*/

    if (adr!=null){
      System.out.println("Suppression de l'adresse : "+adr.getNumeroRue()+" "+adr.getNomRue()+" "+adr.getCodePostal()+" "+adr.getVille()+" "+adr.getPays());
      em.remove(adr);
      
      //int idAdr = adr.getIdAdresse();
      //query = em.createQuery("DELETE FROM Adresse AS adr WHERE adr.idAdresse="+idAdr);
      //System.out.println(query.executeUpdate()+" adresse supprimee");
      //System.out.println ("Adresse supprime");
    }
    em.remove(util);
    em.flush();
    //System.out.println ("Utilisateur supprime !");
  }

  public void delTousLesUtilisateurs (){
    System.out.println("Suppression de tous les utilisateurs !");
    List<Utilisateur> utilisateurs = getTousLesUtilisateurs();
    for (int i=0; i<utilisateurs.size(); i++){
      delUtilisateur(((Utilisateur)utilisateurs.get(i)).getIdUtilisateur());

    }
  }
  
  public InfosUtilisateur rechercherUtilisateur (int idUtil){
    Utilisateur util = getUtilisateur(idUtil);
    Adresse adr = util.getAdresse();
    InfosUtilisateur infos;
    if (adr!=null){
      infos = new InfosUtilisateur (util.getNom(), util.getPrenom(), adr.getNumeroRue(), adr.getNomRue(), adr.getCodePostal(), adr.getVille(), adr.getPays());
    } else {
      infos = new InfosUtilisateur (util.getNom(), util.getPrenom(), 0, "", "", "", "");
    }
    return infos;
  }


}