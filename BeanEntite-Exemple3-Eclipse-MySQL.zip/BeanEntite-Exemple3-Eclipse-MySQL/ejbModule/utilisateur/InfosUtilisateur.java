package utilisateur;

public class InfosUtilisateur implements java.io.Serializable {

  public String nomUtilisateur;
  public String prenomUtilisateur;
  public String nomRueUtilisateur;
  public int numeroRueUtilisateur;
  public String codePostalUtilisateur;
  public String villeUtilisateur;
  public String paysUtilisateur;

  public InfosUtilisateur (String nomUtilisateur, String prenomUtilisateur, int numeroRueUtilisateur, String nomRueUtilisateur, String codePostalUtilisateur, String villeUtilisateur, String paysUtilisateur){
    this.nomUtilisateur = nomUtilisateur;
    this.prenomUtilisateur = prenomUtilisateur;
    this.nomRueUtilisateur = nomRueUtilisateur;
    this.numeroRueUtilisateur = numeroRueUtilisateur;
    this.codePostalUtilisateur = codePostalUtilisateur;
    this.villeUtilisateur = villeUtilisateur;
    this.paysUtilisateur = paysUtilisateur;
  }

}