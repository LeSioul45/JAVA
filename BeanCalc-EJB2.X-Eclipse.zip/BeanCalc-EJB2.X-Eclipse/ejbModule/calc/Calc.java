package calc;

import javax.ejb.*;
import java.rmi.*;

public interface Calc extends EJBObject {
    public double add(double val1, double val2) throws RemoteException;
    public double mult(double val1, double val2) throws RemoteException;
}
