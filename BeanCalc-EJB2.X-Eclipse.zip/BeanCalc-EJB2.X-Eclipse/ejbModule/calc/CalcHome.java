package calc;

import javax.ejb.*;
import java.rmi.*;

public interface CalcHome extends EJBHome {
    public Calc create() throws CreateException, RemoteException;
}
