package calc;

import javax.ejb.*;

public class CalcBean implements SessionBean {

	private static final long serialVersionUID = 1L;
	SessionContext sessionContext;

    public void ejbCreate() { }
    public void ejbRemove() { }
    public void ejbActivate() { }
    public void ejbPassivate() { }

    public void setSessionContext(SessionContext sessionContext) {
        this.sessionContext = sessionContext;
    }

    public double add(double val1, double val2) {
        return val1 + val2;
    }
    public double mult(double val1, double val2) {
        return val1 * val2;
    }
}
