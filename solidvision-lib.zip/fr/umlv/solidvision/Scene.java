/*
 * Created on 16 feb. 2005
 *
 */
package fr.umlv.solidvision;

import javax.media.opengl.GL;

/** 
 * @author Remi Forax
 *
 */
public interface Scene {
  
  /** Add a solid object to the scene.
   * @param object a solid object to add to the scene. 
   */
  public void addSolid(SolidObject object);
  
  /** Add a light to the scene.
   * @param light a light to add to the scene.
   */
  public void addLight(Light light);
  
  /** Set the camera of the scene.
   * @param camera the camera.
   */
  public void setCamera(Camera camera);
  
  /** Get the camera.
   * @return the camera or null otherwise.
   */
  public Camera getCamera();
  
  /** Retrieves a material object (light or solid object) by its id.
   * 
   * @param id identifier (or name) of the material
   * @param type type of the material, {@link Light} or {@link SolidObject}. 
   * @return a material object or null is there is 
   *         no corresponding material object.
   */
  public <M extends MaterialObject> M getMaterialObject(String id, Class<M> type);
  
  /** Add an animator to the scene. An animator
   *  is used to modify a scene before its rendering.
   *  
   * @param animator
   * 
   * @see Animator#animate(GL)
   * @see SceneEnv#display(Scene, boolean)
   */
  public void addAnimator(Animator animator);
  
  /** Setup all scene objects.
   *  This method is called once when the scene is initialized.
   * 
   * @param gl the gl evironment
   * 
   * @see SceneObject#setup(GL)
   * @see SceneEnv
   */
  public void setup(GL gl);
  
  /** Render all solid objects.
   *  This method is called each time the scene need
   *  to be rendered.
   * @param gl the gl evironment
   * 
   * @see SolidObject#render(GL)
   * @see SceneEnv
   */
  public void render(GL gl);
}
