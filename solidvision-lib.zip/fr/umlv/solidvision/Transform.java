package fr.umlv.solidvision;

import javax.media.opengl.GL;

/**
 * This interface stands for affine transformations (i.e a translation, rotation or scale). 
 * Such a coordinate transformation can be represented by a 4x4 matrix
 * with an implied last row of [ 0 0 0 1 ].
 * 
 * @author Rémi Forax
 * 
 * @see TransformableObject
 */
public interface Transform {
  /** Perform the transformation on OpenGL environment.
   * @param gl the OpenGL environment.
   */
  public void performs(GL gl);
}
