package fr.umlv.solidvision;

import java.io.File;

/** interface of textures.
 *  This type is optional, an implementation is free
 *  to provide not provide an implementation of this type.
 * 
 * @author Remi Forax
 * 
 * @see Factory#createTexture(File)
 * @see SolidObject#setTexture(Texture)
 */
public interface Texture {
  /** Returns the width of the texture.
   * @return the width of the texture.
   */
  public int getWidth();
  
  /** Returns the height of the texture.
   * @return the height of the texture.
   */
  public int getHeight();
  
  /** Returns the file containing the data of the texture.
   * @return the file containing the data of the texture.
   */
  public File getFile();
}
