package fr.umlv.solidvision;

import javax.media.opengl.GL;

/** Base type of all objects other that light, camera etc.
 *  of the scene 
 * 
 * @author Remi Forax
 * 
 * @see Scene
 */
public interface SolidObject extends MaterialObject, TransformableObject {
  /** Translates a solid object along each axis.
   *  This method can be called at any time,
   *  even between two scene renderings.
   * 
   * @param dx delta on X axis
   * @param dy delta on Y axis
   * @param dz delta on Z axis
   */
  public void translate(GL gl, float dx, float dy, float dz);
  
  /** Rotate a solid object with an angle along each axis.
   *  This method can be called at any time,
   *  even between two scene renderings.
   * 
   * @param angle angle of the rotation in degree.
   * @param vx on X axis
   * @param vy on Y axis
   * @param vz on Z axis
   */
  public void rotate(GL gl,float angle, float vx, float vy, float vz);
  
  /** Scales a solid object along each axis.
   *  This method can be called at any time,
   *  even between two scene renderings.
   * 
   * @param fx factor on X axis
   * @param fy factor on Y axis
   * @param fz factor on Z axis
   */
  public void scale(GL gl,float fx, float fy, float fz);
  
  /** Changes the texture of the current solid object.
   *  This feature is optional and the implementation
   *  could silently do nothing.
   *  
   * @param texture the texture.
   * 
   * @see #getTexture()
   */
  public void setTexture(Texture texture);
  
  /** Gets the texture of the current object.
   * @return the texture previously set or null if there is no texture
   *  associated with the current object.
   *  
   *  @see #setTexture(Texture)
   */
  public Texture getTexture();
  
  /** Renders the current object.
   *  This method is called each time this object need
   *  to be rendered.
   *  
   * @param gl the OpenGL environment.
   * 
   * @see SceneObject#setup(GL)
   */
  public void render(GL gl);
}
