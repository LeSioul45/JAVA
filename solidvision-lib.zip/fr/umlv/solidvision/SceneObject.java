package fr.umlv.solidvision;

import javax.media.opengl.GL;

/** Base type for all objects that can be added to a {@link Scene}. 
 * 
 * @author Remi Forax
 *
 * @see MaterialObject
 * @see Camera
 */
public interface SceneObject {
  /** Changes the location of the scene object.
   *  This method must not be called after the current object
   *  is rendered.
   *  
   * @param x the x component of the scene object location.
   * @param y the y component of the scene object location.
   * @param z the z component of the scene object location.
   * 
   * @see #getLocation()
   */
  public void setLocation(float x, float y, float z);
  
  /** Returns the location of the current scene object.
   *  The location is the location set by {@link #setLocation(float, float, float)}
   *  or returns the default location of the object.
   *  
   *  The implementation of this method do a defensive copy
   *  of the locations values.
   *  
   * @return an array of 3 floats containing the location of the current scene object.
   * 
   * @see #setLocation(float, float, float)
   */
  public float[] getLocation();
  
  /** Set up the current object.
   *  This method is called once when the scene is initialized.
   *   
   * @param gl the OpenGL environment.
   * 
   * @see SolidObject#render(GL)
   */
  public void setup(GL gl);
}
