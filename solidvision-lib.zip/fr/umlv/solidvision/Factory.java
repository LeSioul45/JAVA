package fr.umlv.solidvision;

import java.io.File;
import java.io.IOException;

/** Allows to create scene objects.
 *  Implementation of this interface is used by the
 *  {@link XMLSceneParser XML scene parser}.
 * 
 * @author Remi Forax
 * 
 * @see XMLSceneParser#parse(Scene, File, Factory)
 */
public interface Factory {
  
  /** Creates a solid objects of a given kind.
   * @param kind a string like "cube", "plane", "sphere", "cyclinder"
   *     etc. 
   * @param id the uniq identifier of the solid object.
   * @return a new solid object.
   * 
   * @throws IllegalArgumentException
   *     if the solid object kind is not understood. 
   *     
   * @see Scene#getMaterialObject(String, Class)
   */
  public SolidObject createSolidObject(String kind, String id);
  
  /** Creates a light.
   * @return a new light.
   * 
   * @see Scene#addLight(Light)
   */
  public Light createLight(String kind);
  
  /** Creates a camera with a screen dimension.
   * @param width the width of the screen.
   * @param height the height of the screen.
   * @return a new camera.
   * 
   * @see Scene#setCamera(Camera)
   */
  public Camera createCamera(String kind, int width, int height);
  
  /** Creates a texture from a file on disk.
   * @param file texture file
   * @return a texture
   * 
   * @throws IOException if the texture can't be loaded.
   * @throws IllegalArgumentException if the image has dimension
   *  that are not power of two.
   * @throws UnsupportedOperationException if textures are not supported
   *  by the current implementation.
   *  
   * @see SolidObject#setTexture(Texture)
   */
  public Texture createTexture(File file) throws IOException;
  
  /** Creates an empty animator.
   * @return a new animator.
   * 
   * @throws UnsupportedOperationException if animators are not supported
   *  by the current implementation.
   * 
   * @see TransformableObject#addTransform(Transform)
   * @see Scene#addAnimator(Animator)
   */
  public Animator createAnimator();
}
