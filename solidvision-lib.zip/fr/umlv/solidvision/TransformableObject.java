package fr.umlv.solidvision;

/** Base type for object that can be transformed by {@link Transform}.
 *  This interface is a common supertype for {@link Animator}
 *  and {@link SolidObject}.
 * 
 * @author Remi Forax
 * 
 * @see Transform
 */
public interface TransformableObject {
  /** Composes the given transformation with the transformation
   *  of the current object.
   *  
   * @param transform the transform to compose.
   */
  public void addTransform(Transform transform);
}
