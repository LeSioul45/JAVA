package fr.umlv.solidvision;

/** A class that represents 3 float color or 4 float color.
 * 
 * @author Rémi Forax
 * 
 * @see MaterialObject#getColor(MaterialKind)
 */
public class Color {
  /** Creates a 3 float color with no alpha channel
   *  or a 4 float color with alpha channel.
   * @param red red component of the color
   * @param green green component of the color
   * @param blue blue component of the color
   * @param alpha an optional alpha channel
   */
  public Color(float... components) {
    if (components.length<3 || components.length>4)
      throw new IllegalArgumentException("component array length is not 3 or 4 "+
          components.length);
    values = components.clone();
  }
  
  /** Returns the red component of the color.
   * @return the red component of the color.
   */
  public float getRed() {
    return values[0];
  }
  
  /** Returns the green component of the color.
   * @return the green component of the color.
   */
  public float getGreen() {
    return values[1];
  }
  
  /** Returns the green component of the color.
   * @return the green component of the color.
   */
  public float getBlue() {
    return values[2];
  }
  
  /** Returns the green component of the color.
   * @return the green component of the color.
   */
  public float getAlpha() {
    if (!hasAphaChannel())
      throw new IllegalStateException("this color has no alpha channel");
    return values[3];
  }
  
  /** Returns true if the current color has an alpha channel.
   * @return true if the current color has an alpha channel.
   */
  public boolean hasAphaChannel() {
    return values.length == 4;
  }
 
  private final float[] values;
}
