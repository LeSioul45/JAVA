package fr.umlv.solidvision;

import javax.media.opengl.GL;

/** Animator used to animate a scene.
 *  The animation is defined by adding transformations
 *  using {@link TransformableObject#addTransform(Transform)}.
 * 
 * @author Rémi Forax
 *
 * @see TransformableObject#addTransform(Transform)
 * @see Scene#addAnimator(Animator)
 * @see SceneEnv#display(Scene, boolean)
 */
public interface Animator extends TransformableObject {
  
  /** This method is called each time a new frame of
   *  the animation is rendered.
   *  This method can only call method that are allowed
   *  to be called after a frame is rendered.
   *  
   * @param gl the gl environment
   */
  public void animate(GL gl);
}
