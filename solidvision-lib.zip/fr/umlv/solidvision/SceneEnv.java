package fr.umlv.solidvision;

import javax.media.opengl.GL;
import javax.media.opengl.GLAutoDrawable;
import javax.media.opengl.GLCanvas;
import javax.media.opengl.GLEventListener;
import javax.media.opengl.GLException;
import javax.swing.JFrame;

import com.sun.opengl.impl.error.Error;
import com.sun.opengl.util.FPSAnimator;

/** Bootstrap class used to display a frame containing a 3D scene.
 * 
 * @author Remi Forax
 * 
 * @see Scene
 */
public class SceneEnv {
  /** Display a frame containing the scene.
   * @param scene the scene to display.
   * @param animated true if the scene must be animated using animators
   *  false otherwise.
   *  
   * @throws IllegalArgumentException if the scene doesn't define a camera.
   */
  public static void display(final Scene scene, boolean animated) {
    final Camera camera=scene.getCamera();
    if (camera == null)
      throw new IllegalArgumentException("the scene doesn't define a camera");
      
    final GLCanvas canvas=new GLCanvas();
    canvas.addGLEventListener(new GLEventListener() {
      public void displayChanged(GLAutoDrawable drawable, boolean modeChanged,
          boolean deviceChanged) {
        // do nothing
      }
      
      public void init(GLAutoDrawable drawable) {
        GL gl = drawable.getGL();
        gl.glClearColor(0, 0, 0, 0);
        gl.glEnable(GL.GL_DEPTH_TEST);
        gl.glShadeModel(GL.GL_SMOOTH);
        
        scene.setup(gl);
      }
      
      public void reshape(GLAutoDrawable drawable, int x, int y, int width,
          int height) {
        
        GL gl = drawable.getGL();
        gl.glMatrixMode(GL.GL_PROJECTION);
        gl.glLoadIdentity();
        
        camera.setup(gl);
        
        gl.glMatrixMode(GL.GL_MODELVIEW);
        gl.glLoadIdentity();
      }
    
      public void display(GLAutoDrawable drawable) {
        GL gl = drawable.getGL();
        
        gl.glClear(GL.GL_COLOR_BUFFER_BIT | GL.GL_DEPTH_BUFFER_BIT);
        scene.render(gl);
      }
    });
    
    if (animated) {
      FPSAnimator animator=new FPSAnimator(canvas, 32);
      animator.start();
    }
    
    JFrame frame=new JFrame();
    frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    frame.add(canvas);
    //frame.setResizable(false);
    frame.setSize(camera.getWidth(), camera.getHeight());
    frame.setVisible(true);
  }
  
  /** An util method that checks if an OpenGL error has occured.
   * @param gl the OpenGL environment
   * @param message a string used to indicate a message
   * @param object the scene object involved or null.
   */
  public static void checkError(GL gl, String message, SceneObject object) {
    int errorCode = gl.glGetError();
    if (errorCode != 0)
      throw new GLException(Error.gluErrorString(errorCode)+"("+errorCode+
        ") in "+message+((object == null) ? "" : " "+object));
  }
}
