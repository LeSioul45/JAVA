package fr.umlv.solidvision;

/** A camera of the scene that defines the screen dimension
 *  and the type of projection.
 *  
 *  To specify the projection, subtypes must implements
 *  the method {@link #setup(javax.media.opengl.GL)}.
 * 
 * @author Remi Forax
 * 
 * @see Scene#setCamera(Camera)
 */
public interface Camera extends SceneObject {
  /** Returns the width of the screen.
   * @return a positive integer representing the width of the screen.
   */
  public int getWidth();
  
  /** Returns the height of the screen.
   * @return a positive integer representing the height of the screen.
   */
  public int getHeight();
}
