package fr.umlv.solidvision;

import java.io.File;
import java.io.IOException;

/**
 * Interface of scene parsers described using
 * the solidVision XML format.
 * 
 * This object is thread safe and can be reused
 * to parse multiple files.
 * 
 * @author Rémi Forax
 *
 * @see SceneEnv
 */
public interface XMLSceneParser {
  
  /** Parse a file, create scene object using the given factory
   *  and store them into scene.
   *  
   * @param scene the scene.
   * @param file the file to parse.
   * @param factory the factory used to create scene objects.
   * 
   * @throws IOException if access to the given file produces an error.
   */
  public void parse(Scene scene, File file, Factory factory) throws IOException;
}
