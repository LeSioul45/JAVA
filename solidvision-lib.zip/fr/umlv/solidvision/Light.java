package fr.umlv.solidvision;

/** Base type for all kind of lights.
 * 
 * @author Remi Forax
 */
public interface Light extends MaterialObject {
  /** Returns the colors of a given material kind.
   *  
   * @param kind the material kind among AMBIANT,
   *        DIFFUSE, SPECULAR. .
   * @return a color using RGB/ARGB format.
   * @throws IllegalArgumentException
   *  if kind pass as argument is SHININESS or EMISSION
   */
  public Color getColor(MaterialKind kind);
  
  /** Changes the colors of a given material kind.
   * 
   * @param kind the material kind among AMBIANT,
   *        DIFFUSE, SPECULAR.
   * @param color a color using RGB/ARGB format.
   * @throws IllegalArgumentException
   *  if kind pass as argument is SHININESS or EMISSION
   *  
   * @see Texture
   */
  public void setColor(MaterialKind kind, Color color);
  
  /** Changes the direction of the current light. 
   *  This method must not be called after the current light
   *  is rendered.
   *  
   * @param x the x component of the light direction.
   * @param y the y component of the light direction.
   * @param z the z component of the light direction.
   */
  public void setDirection(float x, float y, float z);
  
  /**
   * @param exponent
   */
  public void setSpotExponent(float exponent);
  
  /**
   * @param cutoff
   */
  public void setSpotCutOff(float cutoff);
  
  /** Kind of light attenuation.
   * 
   * @author Remi Forax
   * 
   * @see Light#setAttenuation(AttenuationKind, float)
   */
  public enum AttenuationKind {
    CONSTANT,
    LINEAR,
    QUADRATIC
  }
  
  /** Change the attenuation function of the light. 
   * @param kind the attenuation kind among CONSTANT, LINEAR, QUADRATIC.
   * @param value 
   */
  public void setAttenuation(AttenuationKind kind, float value);
}
