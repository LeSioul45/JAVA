package fr.umlv.solidvision;

/** Base type for object that have a unique identifier and
 *  colors. This interface is the common supertype of {@link Light}
 *  and {@link SolidObject}.
 *  
 *  Diffuse, specular and shininess colors are visibles
 *  only if a light is defined in the scene.
 *  
 * @author Remi Forax
 */
public interface MaterialObject extends SceneObject {
  /** Returns a unique identifier of the current object in the scene.
   *  This id is provided during the initialisation of the object
   *  and is used to handle the current object. 
   *  
   * @return a unique identifier of the object.
   * 
   * @see Scene#getMaterialObject(String, Class)
   */
  public String getId();
  
  /** Kind of material color.
   * 
   * @author Remi Forax
   * 
   * @see MaterialObject
   */
  public enum MaterialKind {
    AMBIANT,
    DIFFUSE,
    SPECULAR,
    SHININESS,
    EMISSION
  }
  
  /** Changes the colors of a given material kind.
   * 
   * @param kind the material kind among AMBIANT,
   *        DIFFUSE, SPECULAR, SHININESS or EMISSION.
   * @param color a color using RGB/ARGB format.
   * 
   * @see MaterialKind
   * @see Texture
   */
  public void setColor(MaterialKind kind, Color color);
  
  /** Returns the colors of a given material kind.
   *  This method returns the values previously entered
   *  with the method {@link #setColor(MaterialKind, Color)}
   *  or the default OpenGL values otherwise.
   *  
   * @param kind the material kind among AMBIANT,
   *        DIFFUSE, SPECULAR, SHININESS or EMISSION.
   * @return a color using RGB/ARGB format.
   */
  public Color getColor(MaterialKind kind);
}
