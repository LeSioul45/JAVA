import javax.naming.*;
import javax.rmi.PortableRemoteObject;    
import hello.*;

public class HelloClient{
	public static void main(String[] args) throws Exception {
		try{  
			Context ctx = new InitialContext();
			Object ref = ctx.lookup("HelloEJB");
			HelloHome home = (HelloHome)PortableRemoteObject.narrow(ref,HelloHome.class);
			Hello hello = home.create();

			System.out.println(hello.hello("Claude"));
			hello.remove();
		}catch(Exception e){
			e.printStackTrace();
			System.exit(1);
		}   
	}
}
