package utilisateur;

import javax.ejb.Remote;
import java.util.*;

@Remote public interface UtilisateurAccess {

  public int addUtilisateur (String nom, String prenom);
  public int addUtilisateur (String nom, String prenom, int numRue, String nomRue, String codePostal, String ville, String pays);
  public void setAdresse (int idUtil, int numRue, String nomRue, String codePostal, String ville, String pays);
  public void delUtilisateur (int idUtil);
  public InfosUtilisateur rechercherUtilisateur (int idUtil);
  public void delTousLesUtilisateurs ();
}