package utilisateur;

import java.util.*;
import javax.ejb.*;
import javax.persistence.*;
import javax.naming.*;
import java.io.*;

@Entity
@Table(name="UTLISATEUR")
public class Utilisateur implements Serializable {
  private int idUtil;
  private String nomU;
  private String prenomU;
  private Adresse adresseU;

  public Utilisateur (){}

  @Id
  @GeneratedValue (strategy = GenerationType.IDENTITY)
  public int getIdUtilisateur (){
    return idUtil;
  }

  public void setIdUtilisateur (int idUtilisateur){
    idUtil = idUtilisateur;
  }

  public String getNom (){
    return nomU;
  }

  public void setNom (String nom){
    nomU = nom;
  }

  public String getPrenom (){
    return prenomU;
  }

  public void setPrenom (String prenom){
    prenomU = prenom;
  }

  @OneToOne
  @JoinColumn (name="idAdresseFK", referencedColumnName="idAdresse")
  public Adresse getAdresse (){
    return adresseU;
  }

  public void setAdresse (Adresse adresse){
    adresseU = adresse;
  }
}
